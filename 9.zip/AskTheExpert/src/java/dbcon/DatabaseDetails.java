package dbcon;

public interface DatabaseDetails {
    
    String DRIVER = "com.mysql.jdbc.Driver";
    String CONSTR = "jdbc:mysql://localhost:3308/asktheexpert";
    String USERID = "root";
    String PASS = "";
}
